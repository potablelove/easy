<?php 
       
        function timeago($timeago){
            $currenttime = time(); 
            $remaining_time = $currenttime - $timeago;
            $seconds = $remaining_time;
            $minute = round($remaining_time/60);
            $hour = round($remaining_time/3600);
            $days = round($remaining_time/86400);
            $weeks = round($remaining_time/604800);
            $months = round($remaining_time/2600640);
            $year = round($remaining_time/31207680);
            
            if($seconds <=60){
                echo $seconds."seconds";
            }
            elseif($minute<=60){
                if($minute== 1){
                    echo " 1 minute ago";
                }
                else{
                echo $minute." minutes ago";
                }
            }
            elseif($hour <=24){
                if($hour==1){
                    echo "1 hour ago";
                }
                else{
                    echo $hour." hours ago";
                }
                
            }
            elseif($days<=7){
                if($days==1){
                    echo "1 day ago";
                }
                else{
                    echo $days." days ago";
                }
            } // end of days...
                elseif($weeks<=4){
                if($weeks==1){
                    echo "1 week ago";
                }
                else{
                    echo $weeks." weeks ago";
                }
            } // end of week...
            
                elseif($months<=12){
                if($months==1){
                    echo "1 month ago";
                }
                else{
                    echo $months." months ago";
                }
            } // end of month....
            
                elseif($year<=10){
                if($year==1){
                    echo "1 year ago";
                }
                else{
                    echo $year." years ago";
                }
            }
            // end of year...
            
        }


           


?>