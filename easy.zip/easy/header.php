<!DOCTYPE html>
	<html lang='en' >
		<head>
		<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>
	Easy Money
</title>
            <script src='jquery.js'></script>
						<script src='js/bootstrap.min.js'></script>
			<link rel='stylesheet' type='text/css' href='css/bootstrap.css'>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<script src="myscript.js"></script>
		<script>
		$($(document).ready(function() {
			$(".navbar-toggle").click(function() {
				$("#myNavbar").slideToggle();
			});
		});)

		</script>


			</head>
			<body>
				<nav class="navbar navbar-inverse">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="index.php">Easy Money</a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"> </span>Home</a></li>

	      </ul>
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="#">About Us</a></li>
	        <li><a href="#"> Contact Us</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>
