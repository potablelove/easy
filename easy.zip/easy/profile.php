<?php  
session_start();
        include "header.php";
        $session = $_SESSION['number'];
            if($session == ""){
                header("location:login.php");
            }

?>

 <div class="container">
<ul class="nav nav-tabs nav-justified ">
  <li class="active"><a data-toggle="tab" href="#home">Dash Board</a></li>
  <li><a data-toggle="tab" href="#menu1">Account Details</a></li>
     <li><a data-toggle="tab" href="#menu2">Profile</a></li>
  <li> <a data-toggle="tab" href="#">Log Out</a></li>
</ul>
     </div>
<br>

<br>
<br>
        <div class="container">
<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
      <div class="well" id="well1">
    <div class="row">
        <div class="container">
          <div class="col-md-4" id="dash1">
        <div id="block1">
              <h2 class="h2"> PortIn </h2>
              <p id="pblock1" > Request for PortIn To Increase Your Earing Rate </p>
            <br>
            <button class="btn btn-lg btn-default" id="pin">PortIn </button>
              </div>
        
        </div>
            <br>
        <div class="col-md-4" id="dash2">
        
            <div id="block2">
              <h2 class="h2"> PortOut</h2>
                <p id="pblock1" > Wanna use the money you PortIn, PortOut Now!! </p>
            <br>
            <button class="btn btn-lg btn-default" id="pout">PortOut </button>
            
              </div>
        
        </div>  
            <br>
        <div class="col-md-4" id="dash3">
              <div class="well">
            <h2 class="h2">HirePort</h2>
                <p id="pblock1">Wanna Hire a Port,You ve come to the right channel</p>
                  <br>
                  <button class="btn btn-md btn-warning" id="phire">HirePort </button>
            </div>
        
        </div>        
          </div>
        <!-- end of row !-->
        <br>
        <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">PortIn Your Money</h4>
          <p class="alert alert-info" id="rmoney">Fill the Details Below</p>
      </div>
      <div class="modal-body" id="confirm_c">
          </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

        <!-- End of Modal content--> 
        
         <div id="block3" style="display:none;" class="well">
           
                   <h4 class="text text-info">
                   What do you wanna PortIn !!!
                   </h4>
                   <button class="btn btn-primary btn-sm" id="jb">Job</button>
                     <button type="button" class="btn btn-primary btn-sm" id="mm" data-toggle="modal" data-target="#myModal">Money</button>

            </div>
        
          </div>
  </div>
      
      <div id="block4" style="display:none;" class="well">
            <p class="alert alert-info" id="retjob">Fill in Your Details Bellow</p>
            <form enctype="multipart/form-data" method="get" id="jobsubmit" action="portjob.php" >
                <input type="text" placeholder="Job Name" class="form-control" id="job" name="jobname">
                <input type="text" placeholder="Working Experience" class="form-control" id="work" name="experience">
                    <input type="text" placeholder="Collification" class="form-control" id="col" name="collification">
                <input type="text" placeholder="Location" class="form-control" id="loc" name="location">
                    <input type="number" placeholder="Phone number" class="form-control" id="phone" name="phonenumber">
               
                <br>
                <button type="submit" class="btn btn-sm btn-primary" > submit</button>
                        </form>
        
        </div>
    <div class="row">
        <div class="col-md-6">
            <p class="alert alert-danger" id="checkdanger" style="display:none">
                NO ACTIVE PORT NOW !!!
                
                
                </p>
      <div class="well" id="checkjob" style="display:none">
            
            
            
            </div>
             </div>
        <div class="col-md-6" >
        <div class="well" id="hirewell" style="display:none">
            <input type="text" class="form-control" placeholder="Search For Port" id="psearch">
                <button class="btn btn-sm btn-warning" id="hsubmit">Search</button>
            <hr>
            <p class="alert alert-danger" id="empty" style="display:none">Search Port does not exist</p>
            <p id="response"></p>
            
            </div>
        
        </div>
        
            </div>
    
            </div> <!-- dashboard div ends here !-->
            
    
    
  <div id="menu1" class="tab-pane fade">
    <h3 class="h2">Account Details</h3>
      <p class="alert alert-info" id="acc">Please note that you can only Add one Account</p>
    <ul>
      <li style="display:inline"><a href="#" class="btn btn-lg btn-default" id="add">Add Account</a></li>
         <li style="display:inline"><a href="#" class="btn btn-lg btn-default">Delete Account</a></li>
       
      </ul>
      
      <div class="row">
          <!-- first column !-->
      <div class="col-md-4">
         
          
          <div id="form" style="display:none">
      <form>
      <input type="text" class="form-control" placeholder="Bank Name" id="bank" name="bankname"><br>
           <input type="text" class="form-control" placeholder="Account Name" id="accountname" name="accountname"><br>
           <input type="text" class="form-control" placeholder="Account Number" id="accnumber" name="accountnumber"><br>
          
           <input type="submit" class="btn btn-lg btn-info" value="submit_account" id="sub" name="submit">
      
      </form>
      </div>
          </div>
           <!-- second column !-->
      <div class="col-md-4">
           <div class="myacc">
      
      </div>
          <div id="accdetails">
            
      </div>
          </div>
          
           <!-- third column !-->
      <div class="col-md-4">
           <!-- account details !-->
           <div id="mdt" >
      
      </div>
          </div>
      </div>
      
      
      
  </div>
    
  <div id="menu2" class="tab-pane fade">
   
       <div class="panel panel-info">
            <div class="panel-heading"><h3 class="h2" id="h2">Profile</h3></div>
                <div class="panel-body" id="profileupdate" style="background-color:black; color:white;">
          
            
            </div>
        </div>
      
  </div>
</div>
</div>
     




<?PHP  include "footer.php"; ?>

<style>
    
                    input[type=text],input[type=number]{
        width: 100%;
        height: 50px;
         padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
        background-color: inherit;

    }
    #checkjob{
        background-color: black;
        color: aqua;
        display: block;
        box-shadow: 20px;
        border-radius: 20px;
        width: 100%;
    }
    

    #block1{
        background-color: aqua;
        height: inherit;
        border: 1px solid red;
            border-radius:10px;
        padding: 10px;
    }
    
     #block2{
        background-color: yellow;
        height: inherit;
        border: 1px solid red;
            border-radius:10px;
        padding: 10px;
    }
    #pblock1{
        font-family: serif;
        font-weight: bolder;
    }
    .h2{
        text-align: center;
        font-family: fantasy;
        font-weight: bolder;
    }
    #h2{
        margin: auto;
    }
    #response{
        overflow: scroll;
        height:250;
        overflow-x: hidden;
    }
    #money-panel{
        z-index: 1;
        border: 1px solid red;
        position: relative;
        text-decoration-line: overline;
    }

</style>




<script type="text/javascript">

 $("document").ready(function(){
        
   
            
// retreiving profile from the db...
              setInterval(function(){
          $.ajax({
                     type:"get",
					url:"updateprofile.php?number="+"<?php echo $_SESSION['number'];?>",
                        cache:false,
						success:function(result){
                            
							$("#profileupdate").html(result);
                           
								
                        } 
                    })
    },10000);
     // available balance from db
            setInterval(function(){
          $.ajax({
                     type:"get",
					url:"mymoney.php?",
                        cache:false,
						success:function(result){
                            
							$("#mdt").html(result);
                           
								
                        } 
                    })
    },5000);
     //retreiving money update from the db
      setInterval(function(){
          $.ajax({
                     type:"get",
					url:"money.php",
                        cache:false,
						success:function(result){
                            
							$("#avm").html(result);
                           
								
                        } 
                    })
    },1000);
     
     // retreiving active POrt....
             setInterval(function(){
          $.ajax({
                     type:"get",
					url:"checkjob.php",
                        cache:false,
						success:function(result){
                            if(result == ""){
							$("#checkdanger").show();
                            }
                            else{
                                $("#checkjob").html(result).show();
                            }
								
                        } 
                    })
    },10000);
     
     $("#pin").click(function(){
        $("#block3").show();
     
     });
     $("#jb").click(function(){
         $("#block4").show();
         $("#well1").hide();
       
     });
     //job submit ajax....
     $("#jobsubmit").on( "submit",function(e){
         var job = $("#job").val();
         var work = $("#work").val();
         var loc = $("#loc").val();
         var col = $("#col").val();
         var phone = $("#phone").val();
         var cv = $("#cv").val();
        
         e.preventDefault();
          $.ajax({
                     type:"GET",
					url:"portjob.php",
             
                        data:{jobname:job,experience:work,location:loc,collification:col,phonenumber:phone},
						success:function(result){
                            
							$("#retjob").html(result);
                           
								
                        } 
                    })
     });
     
     
     $("#money").click(function (){
         $("#money-panel").show();
     });
     $("#add").click(function(){
         $("#form").slideToggle();
     })
     $("#sub").on("click", function(e){
         var bankname = $("#bank").val();
         var accountname = $("#accountname").val();
         var accountnumber = $("#accnumber").val();
         var sub = $(this).val();
          e.preventDefault();
         $.ajax({
                     type:"POST",
					url:"account.php",
             cache:false,
                        data:{bankname:bankname,accountname:accountname,accountnumber:accountnumber,submit_account:sub},
						success:function(result){
                            
							$("#acc").html(result);
                           
								
                        } 
                    });
     });
     
      setInterval(function(){
          $.ajax({
                     type:"get",
					url:"myaccount.php",
                        cache:false,
						success:function(result){
                            
							$("#accdetails").html(result);
                           
								
                        } 
                    })
    },5000);
     $("#smoney").on("click", function(){
         var amount = $("#amount").val();
         var day = $("#day").val();
           $.ajax({
                     type:"Post",
               data:{amount:amount,day:day},
					url:"moneyupdate.php",
                        cache:false,
						success:function(result){
                            
							$("#rmoney").html(result);
                           
								
                        } 
                    })
         
     });
     
     $("#mm").on("click", function(){
           $.ajax({
                     type:"Post",
					url:"captcha.php",
                        cache:false,
						success:function(result){
                            
							$("#confirm_c").html(result);
                           
								
                        } 
                    })
     })
     
             
});

 </script>