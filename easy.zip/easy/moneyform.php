 <label for="amount" role="label">Amount</label><br>
        <input type="text" placeholder="Amount" class="form-control" id="amount"><br>
          <label for="days" role="label">Enter day</label><br>
          <input type="text" placeholder="Enter day" class="form-control" id="day"><br>
          <div class="checkbox">
  <label><input type="checkbox" value=""><p>You have agree to the term and condition related to PortIn</p>
        </label>
</div>
        
        <button class="btn btn-sm btn-warning" id="smoney">Submit</button>
      

  