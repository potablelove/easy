<?php
session_start();
			$refid = $_SESSION['userid'];
			$str = rand(1111111111, 999999999);
			$str ="P".$str;
		$conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
		if(isset($_POST['submit_account'])){
			$bankname = $_POST['bankname'];
			$accountname = $_POST['accountname'];
			$accountnumber = $_POST['accountnumber'];
if($bankname == "" || $accountname =="" || $accountnumber ==""){
        echo "One of the field is empty";
            
            }
            else{
                $ins = "INSERT INTO account(bankname,accountname,accountnumber,serialnumber,aref) values('$bankname','$accountname','$accountnumber','$str','$refid')";
                $query = mysqli_query($conn, $ins) or die(mysqli_error($conn));
                if($query){
                    echo "successfull";
                }
            }
            
            
		}
            

?>