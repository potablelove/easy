<?php 
session_start();

    $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
            $refid =   $_SESSION['userid'];
            $jobname    = $_GET['jobname'];
			$experience = $_GET['experience'];
			$collification = $_GET['collification'];
			$location = $_GET['location'];
			$phonenumber = $_GET['phonenumber'];
            $time = time();
            if($jobname =="" || $experience =="" || $collification =="" || $location =="" || $phonenumber ==""){
                        echo " One of the field is empty";
            
            }
            elseif(!is_numeric($phonenumber)){
                echo " Enter a valid phone number ..";
            }
            
            elseif(strlen($jobname)  < 8   || strlen($location) < 3 || strlen($phonenumber) < 11 || strlen($phonenumber)  > 11){
                echo "Invalid Input Job Name must be greater than 8 ";
            }
            else{
                
                 $sel = "SELECT * FROM job where jref = '$refid' and confirm = 0";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
               $num = mysqli_num_rows($query);
            if($num > 0 ){
                echo " <p class='alert alert-danger'> You still have a job in a waiting list </p>";
            }
                
               else{ 
            $ins = "INSERT INTO job(jobname,experience,collification,location,phonenumber,time,jref) values ('$jobname','$experience','$collification','$location','$phonenumber','$time','$refid')";
                        $query = mysqli_query($conn,$ins) or die(mysqli_error($conn));
                if($query){
                    echo "successful";
                }
            }
        
         }
            

            
            
        

            

        








?>