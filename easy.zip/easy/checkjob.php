<script src="jquery.js"></script>
<?php
session_start();
        include "timeago.php";
        $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
     $refid =   $_SESSION['userid'];
        
        $sel = "SELECT * FROM hire inner join job on hire.hirefor = job.jobid inner join ref on ref.refid = job.jref where hireby ='$refid' and hireconfirm = 1 ";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
        $num = mysqli_num_rows($query);
        if($num > 0){
            while($row = mysqli_fetch_assoc($query)){
                    $firstname = $row['firstname'];
                    $lastname = $row['lastname'];
                    $jobname = $row['jobname'];
                     
?>
       
            <p>You hire:<span class='text text-warning'> <?php echo $firstname ." ". $lastname; ?>  </span></p>
                    <p>For the Job :<span class='text text-warning'> <?php echo $jobname; ?>  </span></p>
<br>
            <span class="alert alert-danger"> Note that we are waiting for the invitation to be confirm by User. </span>
            



<?php
            } // end of while loop...
        } // end of if loop....
            else{
                
                $sel = "SELECT * FROM hire inner join job on hire.hirefor = job.jobid inner join ref on ref.refid = hire.hireby where hirewho ='$refid' and hireconfirm = 1 ";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
        $num = mysqli_num_rows($query);
        if($num > 0){
            while($row = mysqli_fetch_assoc($query)){
                    $firstname = $row['firstname'];
                    $lastname = $row['lastname'];
                    $jobname = $row['jobname'];
                    $phone = $row['phonenumber'];
                        $jobid = $row['jobid'];
                
                
           ?> 

<p>You are hired by:<span class='text text-warning' > <?php echo $firstname ." ". $lastname; ?>  </span></p>
                    <p>For the Job :<span class='text text-warning'> <?php echo $jobname; ?>  </span></p>
<br>
<button class="btn btn-warning btn-sm con" id=" <?php echo $jobid; ?>">confirm </button>


    <?php            
               
            }
        }
                
      }

            ?>
                
                <?php
               
                    
                    
                    $sel = "SELECT * FROM job inner join ref on ref.refid = job.jref where jref = '$refid' and confirm = 0";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
            $num = mysqli_num_rows($query);
                
            while($row = mysqli_fetch_assoc($query)){
                    $job = $row['jobname'];
                    $time = $row['time'];
                    $jobid = $row['jobid'];
              
                    ?>
<hr>
<div class="alert alert-danger" style="display:none; z-index:1; position:absolute" id="cinfo"> You wanna cancel the request
 <button title="cancel request" class="btn btn-xs btn-warning" id="yess">Yes</button>
 <button title="No" class="btn btn-xs btn-success" id="no">No</button>
</div>
<div class="hover" id="<?php echo $refid;  ?>" data-trigger="hover" >
        <h3> PortIn For Job</h3>
        <p class="text text-warning">As a: <?php echo $job; ?></p>
        <p>No active Port for your Request Now,Don't worry your Port shall be active very soon..</p>
        <p class="text text-warning"><?php  $times = timeago($time);
                    echo $times;     ?></p>
                <button title="cancel request" class="btn btn-xs btn-primary cancel" id="<?php echo $job; ?>">Cancel</button>
     
<hr>
</div>

                    
                    <?php
            } // end of while loop....
    
                
                
           
            
?>

<script src="js/bootstrap.min.js"></script>

<script type="text/javascript">

 $("document").ready(function(){
        $(".cancel").on("click",function(){
           $("#cinfo").show();
            
        });
      $("#yess").on("click",function(){
        alert("deleted");
     
     });
    
$(".hover").popover({
        title:fetchdatas,
            html:true,
                placement:'top'
        });
     function fetchdatas(){
            var fetchdata = "";
         var element = $(this).attr("id");
        
         $.ajax({
                     type:"get",
					url:"hoverjob.php",
                data:{refid:element},
                        cache:false,
                async : false,
						success:function(result){
                        fetchdata = result;	
                        } 
                    });
        return fetchdata;
     } 
     
        
});

 </script>
