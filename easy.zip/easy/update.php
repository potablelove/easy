<?php
 session_start();

         $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
 $num =   $_SESSION['number'] ;
            if(isset($_GET['s1'])){
                $username = $_GET['u'];
               
                
                if($username == ""){
                    echo "Invalid Input";
                }
                else{
                    $update = "UPDATE ref set username = '$username' where number = '$num' ";
                    $query = mysqli_query($conn,$update) or die(mysqli_error($conn));
                    if($query){
                        echo "successful";
                    }
                    else{
                        echo "error Updating";
                    }
                }
                
                
            }
    // end of isset if s1 loop.....
            elseif(isset($_GET['s2'])){
                $firstname = $_GET['u'];
                
                if($firstname == ""){ 
                    echo "Invalid Input";
                }
                else{
                    $update = "UPDATE ref set firstname = '$firstname' where number = '$num' ";
                    $query = mysqli_query($conn,$update) or die(mysqli_error($conn));
                    if($query){
                        echo "successful";
                    }
                    else{
                        echo "error Updating";
                    }
                }
                
                
            }
            // end of elseif loop.... 1
                elseif(isset($_GET['s3'])){
                $lastname = $_GET['u'];
                if($lastname == ""){
                    echo "Invalid Input";
                }
                else{
                    $update = "UPDATE ref set lastname = '$lastname' where number = '$num' ";
                    $query = mysqli_query($conn,$update) or die(mysqli_error($conn));
                    if($query){
                        echo "successful";
                    }
                    else{
                        echo "error Updating";
                    }
                }
                
                
            }

?>