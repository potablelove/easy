<?php
               session_start();
include "timeago.php";
 $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
    
           
            $refid = $_GET['refid'];
                 
                    
                    $sel = "SELECT * FROM job inner join ref on ref.refid = job.jref where jref = '$refid' and confirm = 0  ";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
            $num = mysqli_num_rows($query);
                
            while($row = mysqli_fetch_assoc($query)){
                    $job = $row['jobname'];
                    $col = $row['collification'];
                    $exp = $row['experience'];
                    $loc = $row['location'];
                    $phone = $row['phonenumber'];
                    $time = $row['time'];
                   
              
                    ?>

<p id="ph">Job Name: <span class='text text-warning'> <?php echo $job; ?>  </span></p>
<p  id="ph">Collification : <span class='text text-warning'> <?php echo $col; ?>  </span></p>
<p  id="ph">Experience : <span class='text text-warning'> <?php echo $exp; ?>  </span></p>
<p id="ph">Location : <span class='text text-warning'> <?php echo $loc; ?>  </span></p>
<p id="ph">Phonenumber : <span class='text text-warning'> <?php echo $phone; ?>  </span></p>
<p id="ph">Time: <span class='text text-warning'> <?php $times = timeago($time); echo $times; ?>  </span></p>

<hr>




<?php
                
            }
                ?>

 
<style>
    #ph{
        color:black;
        font-weight:bolder;
    }



</style>