

 $("document").ready(function(){
    $("#phire").on("click",function(){
        $("#hirewell").show();
    });
     $("#psearch").on("keydown", function(){
         var q = $(this).val();
         
             $.ajax({
                     type:"get",
					url:"hireport.php?q="+q,
                        cache:false,
						success:function(result){
                            if(result==""){
                                $("#empty").show();
                            }
                            else{
							$("#response").html(result);
                                 $("#empty").hide();
                           
                            }
								
                        } 
                    });
         
         
         });
   
    

});

 