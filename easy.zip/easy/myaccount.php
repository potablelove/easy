<?php

session_start();
        $conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
        $refid = $_SESSION['userid'];
		$sel = "SELECT * FROM account where aref ='$refid'";
        $query = mysqli_query($conn, $sel) or die(mysqli_error($conn));
        $num = mysqli_num_rows($query);
if($num < 1){
    echo "<p class='alert alert-danger'>no active account Yet</p>";
}
    else{
        while($row = mysqli_fetch_assoc($query)){
   
        $bankname = $row['bankname'];
            $aname = $row['accountname'];
            $number = $row['accountnumber'];
            $serial = $row['serialnumber'];
               

?>
        <div class="panel panel-default" id="panel-acc">
  <div class="panel-body">
            <p>Bank Name: <span class="text text-warning" style="font-weight:bolder"><?php  echo $bankname; ?></span></p>
             <p> Account Name: <span class="text text-warning" style="font-weight:bolder"><?php  echo $aname; ?></span></p>
             <p> Account Number: <span class="text text-warning" style="font-weight:bolder"><?php  echo $number; ?></span></p>
             <p> Unique Serial Number: <span class="text text-warning" style="font-weight:bolder"><?php  echo $serial; ?></span></p>
            
            </div>
</div>

<?php
        }
        
    }
            
            ?>
<style>

    #panel-acc{
        box-shadow: 10px 10px 10px grey;
    }


</style>