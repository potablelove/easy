<!DOCTYPE html>
	<html lang='en' >
		<head>
		<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>
	Easy Money
</title>
            <script src='jquery.js'></script>
			<link rel='stylesheet' type='text/css' href='css/bootstrap.css'>
<script src='js/bootstrap.min.js'></script> 
            <style>
            
                
                .firstdiv{
                    
                    background-color: dodgerblue;
                   
                    margin-top: 100px;
                  
                }
                input[type=text],input[type=password]{
        width: 100%;
        height: 50px;
         padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
        background-color: inherit;

    }
                p{
                    color: darkblue;
                }
                body{
                    background-color: #eee;
                }
                .alerts{
                    border: 2px solid red;
                }
                #info{
                    color: red;
                    font-weight: bold;
                    font-family: courier;
                }
                #p1{
                    color: wheat;
                    font-weight: bolder;
                }
            </style>
			</head>
<body>
<div class="container">
    <div class="row">
    <div class="col-md-12">
    
    <div class="well firstdiv"> 
    <p id="p1"> Please enter your username and password</p>
    <div class="well"> 
    <form role="form" method="post" >
        <p id="info"></p>
        <input class="form-control" placeholder="username" name="username" type="text" id="username"><br>
     <input class="form-control" placeholder="Password" name="password" type="password" id="password"><br>
        <a href="#" class="text text-info" id="forget">Forget Username or Password?</a>
        <p id="forgetform" style="display:none;">
    <br>
    <br> Enter your Pin
    <br>
    <input class='form-control' placeholder='Password' name='number' type='password' id='number'>
    <br>
    <br>
    <input class='btn btn-primary btn-lg' type='submit' name='submit1' id='submit1' value='submit'>
        </p>
        <br />
            
         <br />
         <input class="btn btn-default btn-lg"  name="submit" type="submit" value="submit" id="submit">
        </form>
 </div>
    </div>
    
    </div>
    </div>


</div>
        </body>
</html>
<script type="text/javascript">

 $("document").ready(function(){
         $("#submit").click(function(e){
            var num = $("#username").val();
             var pass  = $("#password").val();
             
            e.preventDefault();
                if(num.length == "" || num.length < 4 ){
                     e.preventDefault();
                  $('#info').html(" Wrong Username ").show().delay(5000).hide('fast');
                  $('#username').addClass("alerts");
                }
              else if(pass.length == "" || pass.length < 4 ){
                  $('#username').removeClass("alerts");
                     e.preventDefault();
                  $('#info').html(" Password Too short ").show().delay(5000).hide('fast');
                     $('#username').removeClass("alerts");
                  $('#password').addClass("alerts");
                }
             else{
                  $('#password').removeClass("alerts");
               
                  $.ajax({
                     type:"get",
					url:"checklogin.php?username="+num +"&password="+pass,
                        cache:false,
						success:function(result){
                            
							$("#info").html(result).show();
                            $('#username,#password').removeClass("alerts");
								
                        } 
                    })
             }
                
         })
            $("#forget").click(function(){
               $("#username,#password, #submit").hide();
                $("#forget").remove();
                 $("#forgetform").show();
            });
     
         
});

 </script>