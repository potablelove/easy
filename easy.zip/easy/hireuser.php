<?php  
session_start();
     $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
         
        $session = $_SESSION['number'];
            if($session == ""){
                header("location:login.php");
            }
            $hireby =  $_SESSION['userid'];
            $hirewho = $_GET['ref'];
            $hirefor = $_GET['job'];
                $confirm = 1;
        $ins  = "INSERT INTO hire (hireby,hirefor,hirewho,hireconfirm) values('$hireby','$hirefor','$hirewho','$confirm')";
        $query = mysqli_query($conn,$ins) or die (mysqli_error($conn));
            if($query){
               $up = "UPDATE job set confirm = 1 where jobname ='$hirefor'";
                $query = mysqli_query($conn,$up) or die (mysqli_error($conn));
                if($query){
                    echo "successful";
                }
            else{
                echo "failed";
            }
        }









?>