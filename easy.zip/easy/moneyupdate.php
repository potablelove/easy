<?php
session_start();
/*  $day = 5;
    $amount = 10000;
    function initail($day,$amount){
        
        $inamount = $amount/100*30; //3000
        $sec = 60*60*24*$day ."<br>";
$inamount = $inamount/$sec;
      $c = 1481554067; 
        $d = time();
        $e = $d - $c;
        if($e < $sec){
           $amount += $inamount;
            return $amount;
           
        }
    }

 
$a = initail($day, $amount);
echo $a;


*/


$conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
        $refid = $_SESSION['userid'];
		$amount = $_POST['amount'];
        $day = $_POST['day'];
        $av = $amount;
        $time = time();
if($amount == "" || $day ==""){
    echo "One of the field is empty!!!";
}
    else{
        $ins = "INSERT INTO money(amount,day,time,available, mref) values('$amount','$day','$time','$av','$refid')";
        $query = mysqli_query($conn,$ins) or die (mysqli_error($conn));
        if($query){
            echo "successful";
        }
        
        
    }























?>