<?php
 session_start();

         $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
          if(isset($_GET['did'])){
              $q = trim($_GET['did']);
               $sel = "SELECT * FROM job inner join ref on ref.refid = job.jref where refid ='$q' and confirm = 0 ";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
               $num = mysqli_num_rows($query);
            if($num == 0 ){
                echo " <p class='alert alert-danger'> not available </p>";
            }
            else{
               while($row = mysqli_fetch_assoc($query)){
                    $job = $row['jobname'];
                   $firstname = $row['firstname'];
                   $lastname = $row['lastname'];
                   $col = $row['collification'];
                   $loc = $row['location'];
                   $exp = $row['experience'];
                   $phone = $row['phonenumber']; 
                   $refid = $row['refid'];
                   $jobid = $row['jobid'];
          



?>
        <div class="panel panel-default">
  <div class="panel-body">
    <p>Career:  <span class="text text-warning"><?php echo $job; ?> </span></p>
     <p>Firstname :  <span class="text text-warning"><?php echo $firstname; ?> </span></p>
            <p>Lastname:  <span class="text text-warning"><?php echo $lastname; ?> </span></p>
        <p>Collification :  <span class="text text-warning"><?php echo $col; ?> </span></p>
      <p>Working Experience:  <span class="text text-warning"><?php echo $exp; ?> </span></p>
     <p>Location :  <span class="text text-warning"><?php echo $loc; ?> </span></p>
     <p>Phone Number:  <span class="text text-warning"><?php echo $phone; ?> </span></p>
    <p> <button class="btn btn-sm btn-success suc" id="<?php echo $refid; ?>" value="<?php echo $jobid; ?>" >Hire</button> 
        <button class="btn btn-sm btn-danger" value="<?php echo $refid; ?>" id="back">Back</button>
            
            
            </div>
</div>


<?php
               }
            }
          }
                   
                   ?>



<script src="jquery.js"></script>
<script type="text/javascript">

 $("document").ready(function(){
        $(".suc").on("click", function(e){
            var ref = $(this).attr("id");
            var job = $(this).val();
             e.preventDefault();
          $.ajax({
                     type:"GET",
					url:"hireuser.php",
             
                        data:{ref:ref,job:job},
						success:function(result){
                            
							$("#hirewell").html(result);
                           
								 
                        } 
                    })
            
        })

});

 </script>
