<?php
session_start();

    $val = $_SESSION['cap'];
    $cap = $_POST['cap'];
// validating captcha......
    if($cap == $val){
        
        
        
        ?>
    <p class="alert alert-danger" style="display:none" id="err"></p>
<div id="enter_amout">
<label for="amount" role="label">Amount</label><br>
        <input type="text" placeholder="Amount" class="form-control" id="amount"><br>
          <label for="days" role="label">Enter day</label><br>
          <input type="text" placeholder="Enter day" class="form-control" id="day"><br>
          <div class="checkbox">
  <label><input type="checkbox"  id="check"><p>You have agree to the term and condition related to PortIn</p>
        </label>
</div>
        
        <button class="btn btn-sm btn-warning" id="smoney">Submit</button>
      
</div>
<?php 
    }
    else{
        echo "Incorrect Pin";
     header("location:captcha.php");
    
    }
    




?>
<script type="text/javascript">

 $("document").ready(function(){

$("#smoney").click(function(){
   var amount = $("#amount").val();
    var day = $("#day").val();
    $.ajax({
                     type:"POST",
					url:"moneyupdate.php",
                    data:{amount:amount,day:day},
                        cache:false,
						success:function(result){
                           if(result != "successful"){
                          $("#err").html(result).show();
                        }
                            else{
                                $("#enter_amout").html(result);
                                  $("#err").hide();
                            }
                            
                        }
						                });
})

});

 </script>