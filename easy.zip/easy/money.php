<?php
session_start();
             function initial($day,$amount,$time){
        
        $inamount = $amount/100*30; //3000
        $sec = 60*60*24*$day ."<br>";
$inamount = $inamount/$sec;
                
      $uploadtime = $time; 
        $currenttime = time();
        $remainingtime = $currenttime - $uploadtime;
        if($remainingtime <= $sec){
          
            $conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
        $refid = $_SESSION['userid'];
		$up ="UPDATE money set available=available+$inamount where mref='$refid' and timeup = 0";
            $query = mysqli_query($conn, $up) or die(mysqli_error($conn));
                if($query){
                    $sel = "SELECT * FROM money where mref ='$refid'";
        $query = mysqli_query($conn, $sel) or die(mysqli_error($conn));
      if($query){
                    while($row = mysqli_fetch_assoc($query)){
   
        $available = $row['available'];
                        return ceil($available);
                        }
                    } 
                }
           
        }
                 else{
                     $conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
        
                     $up ="UPDATE money set timeup = timeup +1";
            $query = mysqli_query($conn, $up) or die(mysqli_error($conn));
            
                 }
    }


$conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
        $refid = $_SESSION['userid'];
		$sel = "SELECT * FROM money where mref ='$refid' and timeup = 0";
        $query = mysqli_query($conn, $sel) or die(mysqli_error($conn));
        $num = mysqli_num_rows($query);

if($num < 1){
    echo "<p class='alert alert-danger'>no active money yet Yet</p>";
}
    else{
        while($row = mysqli_fetch_assoc($query)){
   
        $amount = $row['amount'];
            $day = $row['day'];
            $time = $row['time'];
           

?>
<p><?php   echo initial($day,$amount,$time);   ?></p>



<?php
        }
    }
            
            



?>