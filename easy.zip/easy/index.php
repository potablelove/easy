<?php session_start(); include("header.php"); ?>
		<div class="container">
				<div class="jumbotron" id="jumb">
					<!--  for welcome message !-->

						<h1>Welcome to Easy Money</h1>
						<p class="lead"> You are on the right track on of being a successfull fellow in life..<br />
							we welcome you..
					</div>

					</div>
				<div class="blockquote">
					<div class="container">
				<!-- blockquote !-->
					<blockquote>
						Am so grateful for Easy Money they make my dream come true through the internet<br>
						-janet
						</blockquote>
					</div>
				</div>
			<div class="well">
				<div class="row">
					<div class="col-md-8">
					<!-- this col for message !-->
				<center>	<h1><small>Our Ideology </small></h1></center>
					</div>
				<div class="col-md-4">
					<!-- this col for input !-->
				<div class="well formwell">
					<p class="text text-info forminfo">Please type in your referral number</p>
					<div class="well">
                        <p class="text text-danger" id="info" style="display:none; width:50%;"></p>
					<form method="get">
						<input type="text" class="form-control" placeholder="number" name="number" id="number">
					<input type="submit" class="btn btn-primary" value="submit" id="submit">
						</form>
					</div>
					</div>

					</div>
				</div> <!-- end of row !-->
				</div>
				<div class="well" id="wellimage">
					<!-- 4 image !-->

					<div class="row">
					<div class="col-md-3">
					<!-- this col for image !-->
					<img src="image/m.jpg" alt="image 1" class="img-thumbnail" height="300" width="300">
					</div>
						<div class="col-md-3">
					<!-- this col for image !-->
					<img src="image/m1.jpg" alt="image 1" class="img-thumbnail" height="300" width="300">
					</div>
						<div class="col-md-3">
					<!-- this col for image !-->
					<img src="image/m2.jpg" alt="image 1" class="img-thumbnail" height="300" width="300">
					</div>
						<div class="col-md-3">
					<!-- this col for image !-->
					<img src="image/m4.jpg" alt="image 1" class="img-thumbnail" height="300" width="300">
					</div>

					</div>
				</div>

                <?php include("footer.php"); ?>
			<script>
 $("document").ready(function(){
        $("#submit").click(function(e){
            var num = $("#number").val();

            e.preventDefault();
                if(num.length == "" || num.length < 6 || num.length > 6 ){
                     e.preventDefault();
                  $('#info').html("Incorrect referral pin " +num).show().delay(2000).hide('fast');
                }
            else{
                             $.ajax({
                                type:"get",
					url:"check.php?number="+num,
                        cache:false,
						success:function(result){
							$("#info").html(result).show();

                        }
                    })
            }
        })

});

 </script>





</script>
