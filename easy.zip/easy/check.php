<?php
            session_start();
            
         $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
        $number = $_GET['number'];
                $_SESSION['number'] = $_GET['number'];
        $sel = "SELECT * FROM ref where number = '$number'";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
        $num = mysqli_num_rows($query);
            if($num > 0 && $num == 1){
                
            
?>
              <a href="welcome.php" class='btn btn-md btn-success'>Continue</a>  
<?php
              // end of if loop  
            }
    else{
        echo "error pin";
    }
?>