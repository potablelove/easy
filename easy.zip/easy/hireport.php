<?php

 session_start();

         $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
          if(isset($_GET['q'])){
              $q = trim($_GET['q']);
              if(strlen($q) < 4){
                  echo "<p class='alert alert-danger'> short to search for</p>";
              }
              else{
               $sel = "SELECT * FROM job inner join ref on ref.refid = job.jref where jobname like '%$q%' and confirm = 0 ";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
               $num = mysqli_num_rows($query);
            if($num == 0 ){
                echo " <p class='alert alert-danger'> not available </p>";
            }
            else{
               while($row = mysqli_fetch_assoc($query)){
                    $job = $row['jobname'];
                   $firstname = $row['firstname'];
                   $lastname = $row['lastname'];
                   $col = $row['collification'];
                   $id = $row['refid'];
          
              
          ?>
<blockquote>  <p class="text text-primary"><?php echo  $job;  ?></p>
                <p> <?php echo "Name : ".  $firstname. " ".$lastname ."<br> collification : ".$col;  ?></p>
            <button class="btn btn-xs btn-warning details" id="<?php echo $id ?>">Details</button>
</blockquote>
            <hr>

<?php
               }
                
            }
                   
        } // end of while loop....
          } // end of isset...


?>
<script src="jquery.js"></script>
<script type="text/javascript">

 $("document").ready(function(){
     $(".details").on("click", function(){ 
        var did = $(this).attr("id");
         
          $.ajax({
                     type:"get",
					url:"hiredetails.php?did="+did,
                        cache:false,
						success:function(result){
                            
							$("#response").html(result);
                                
								
                        } 
                    });
     })


});

 </script>



