<?php
session_start();
$conn = mysqli_connect("localhost","root","","ref") or die ("could not connect");
        $refid = $_SESSION['userid'];
		$sel = "SELECT * FROM money where mref ='$refid' ";
        $query = mysqli_query($conn, $sel) or die(mysqli_error($conn));
   
        while($row = mysqli_fetch_assoc($query)){
   
        $amount = $row['amount'];
            $day = $row['day'];
            $av = $row['available'];
           

?>

<div class="panel panel-default" id="port_details">
  <div class="panel-body">
            <p>Amount PortIn: <span class="text text-warning" style="font-weight:bolder"><?php  echo $amount; ?></span></p>
             <p> Days To Yield: <span class="text text-warning" style="font-weight:bolder"><?php  echo $day; ?></span></p>
      <p> Available to Portout: <span class="text text-warning" style="font-weight:bolder"><?php  echo $av; ?></span></p>
             

    </div>
</div>
<?php
        }
    
            
            
?>
<style>
    #port_details{
        box-shadow: 10px 10px 10px grey;
    }


</style>
