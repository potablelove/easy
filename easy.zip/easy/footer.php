	<div class="footer">
                <p>&copy;potable <?php echo date('Y'); ?></p>
                <p> Easy Money is design by Potable</p>
				</div>
		</body>
</html>
