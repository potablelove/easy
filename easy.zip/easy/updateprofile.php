    <?php
          $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
        $number = $_GET['number'];
                    if($number == ""){
                        header("location:index.php");
                    }
                    else{
         $sel = "SELECT * FROM ref where number = '$number'";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
            while($row = mysqli_fetch_assoc($query)){
                    $image = $row['picture'];
                    $firstname = $row['firstname'];
                    $lastname = $row['lastname'];
                     $number = $row['number'];
                $money = $row['money'];
                $username = $row['username'];
                $dates = $row['dates'];
           
        
        ?>
        <img src="<?php echo $image; ?>" class="img img-circle"  alt="profile image" width="304" height="236">
                    <hr>
                    <p style="display:none;" class="alert alert-info" id="suc1"></p>
                   <h4>Username</h4>
                    <p class="text text-primary"><?php echo $username; ?> </p>
                    <p> <a href="#" id="a1">Edit</a> </p>
                    <p> <input type="text" class="form-control" id="e1" name="u" placeholder="Edit Username" style="display:none;"> 
                        <input type="submit" class="btn btn-default" id="i1" style="display:none;" value="Update" name="s1"> </p>
                    <hr>
                    <p style="display:none;" class="alert alert-info" id="suc2"></p>
                    <h4>Firstname</h4>
                    <p class="text text-primary"><?php echo $firstname; ?></p>
                    <p> <a href="#" id="a2">Edit</a> </p>
                    <p> <input type="text" class="form-control" id="e2" placeholder="Edit Firstname" style="display:none;"> <input type="submit" class="btn btn-default" id="i2" style="display:none;" value="Update"> </p>
                    <hr>
<p style="display:none;" class="alert alert-info" id="suc3"></p>
                    <h4>Lastname</h4>
                         <p class="text text-primary"><?php echo $lastname; ?></p>
                    <p> <a href="#" id="a3">Edit</a> </p>
                    <p> <input type="text" class="form-control" id="e3" placeholder="Edit Lastname" style="display:none;"> <input type="submit" class="btn btn-default" id="i3" style="display:none;" value="Update">  </p>
        <hr>
                    <h4>Referral Pin</h4>
                         <p class="text text-primary"><?php echo $number; ?></p>
                    <hr>
                     <h4>My Port</h4>
                    <p class="text text-primary"> Port =><span class="badge"><?php echo $money; ?> </span> </p>
                    <hr>
                    <h4>Register Date</h4>
                    <p class="text text-primary"><?php echo $dates; ?></p>
                    <hr>
            
            
                    
                      <?php
                //end of while loop...
            }
                        // end of else loop....
                    }
        ?>


<script src="jquery.js"></script>
<script>
$(document).ready(function(){
     $("#a1").click(function(e){
         e.preventDefault();
         $(this).hide();
            $("#e1,#i1").show();
        
             
     });
     $("#i1").click(function(){
                 
                 var u =  $("#e1").val();
                 // ajax one working.....
                       $.ajax({
                     type:"get",
					url:"update.php?u="+u+"&s1="+"s1",
                        cache:false,
						success:function(result){
							$("#suc1").html(result).show().delay(2000).hide(1000);
								
                        } 
                    })
             });
    // edit 2....
    $("#a2").click(function(e){
         e.preventDefault();
         $(this).hide();
            $("#e2,#i2").show();
        
             
     });
    
    $("#i2").click(function(){
                 
                 var u =  $("#e2").val();
                 // ajax one working.....
                       $.ajax({
                     type:"get",
					url:"update.php?u="+u+"&s2="+"s2",
                        cache:false,
						success:function(result){
							$("#suc2").html(result).show().delay(2000).hide(1000);
								
                        } 
                    })
             });
     $("#a3").click(function(e){
         e.preventDefault();
         $(this).hide();
            $("#e3,#i3").show();
        
             
     });
    $("#i3").click(function(){
                 
                 var u =  $("#e3").val();
                 // ajax one working.....
                       $.ajax({
                     type:"get",
					url:"update.php?u="+u+"&s3="+"s3",
                        cache:false,
						success:function(result){
							$("#suc3").html(result).show().delay(2000).hide(1000);
								
                        } 
                    })
             })
    
})





</script>