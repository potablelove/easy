<?php
session_start();
        $n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
            $sh = str_shuffle($n);
                $sh = substr($sh,0,5);
            $_SESSION['cap'] = $sh;
               $sh;

?>

<p class="text text-info" id="capinfo">enter the captcha!!!!</p>
<br>
<p style="font-weight:bolder; color:red; font-size:50px; text-decoration: line-through;"><i><?php echo $sh ?></i></p>
<form>
<input type="text" placeholder="Enter the Captcha" class="form-control" id="cap" name="cap">
<button type="submit" class="btn btn-xs btn-warning" name="sub" id="subcap">submit</button>
</form>


<script src="jquery.js"></script>
<script type="text/javascript">

 $("document").ready(function(){

$("#subcap").on("click", function(e){
    e.preventDefault();
    var cap = $("#cap").val();
    if(cap.length == ""){
        $("#capinfo").html("You can't submit empty value");
        
    }
    else{
         $.ajax({
                     type:"Post",
            data:{cap:cap},
					url:" checkcaptcha.php",
                        cache:false,
						success:function(result){
                            
							$("#confirm_c").html(result);
                           
								
                        } 
                    })
    }
 
})

});

 </script>