<?php session_start(); include("header.php"); ?>
            <div class="row">
                <div class=" col-sm-9 col-md-9 ">
                
        <div class="panel panel-info">
            <div class="panel-heading"><h3><center>Register Now !!!</center></h3></div>
            <div class="panel-body">
         <div class="well">
        <!-- register !-->
        <table class="table">
            <form method="post" action="register.php" enctype="multipart/form-data">
                <tr>
                    <td>
                        <input type="text" name="username" class="form-control" placeholder="Username">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="firstname" class="form-control" placeholder="Firstname">
                    </td>
                    <td>
                        <input type="text" name="lastname" class="form-control" placeholder="Lastname">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="password" name="password" class="form-control" placeholder="Password">
                    </td>
                    <td>
                        <input type="password" name="cpassword" class="form-control" placeholder="Confirm Pasword">
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="radio">
                            <label for="male">
                                <input type="radio" name="gender" value="Male">Male</label>

                            <label for="female">
                                <input type="radio" name="gender" value="Female">Female
                            </label>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="hidden" value="10" name="money">
                        <label for="image">Profile Image</label>
                        <input type="file" name="image" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" name="submit" class="btn btn-primary btn-lg" value="submit">
                    </td>
                </tr>
            </form>
        </table>
    </div>
           
        </div>
                                                                                                        </div>
                
                </div>
   <div class=" col-sm-3 col-md-3 ">
                   <!-- referral profile !-->
        <div class="panel panel-primary">
            <div class="panel-heading"><h3>Referral Profile</h3></div>
                <div class="panel-body">
        <?php
          $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
        $number = $_SESSION['number'];
                    if($number == ""){
                        header("location:index.php");
                    }
                    else{
         $sel = "SELECT * FROM ref where number = '$number'";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
            while($row = mysqli_fetch_assoc($query)){
                    $image = $row['picture'];
                    $firstname = $row['firstname'];
                    $lastname = $row['lastname'];
                     $number = $row['number'];
           
        
        ?>
        <img src="<?php echo $image; ?>" class="img img-thumbnail"  alt="profile image" width="300" height="400">
                   
                    <h4>Firstname</h4>
                    <p class="text text-primary"><?php echo $firstname; ?></p>
                    <hr>
                    <h4>Lastname</h4>
                         <p class="text text-primary"><?php echo $lastname; ?></p>
        <hr>
                    <h4>Referral Pin</h4>
                         <p class="text text-primary"><?php echo $number; ?></p>
        
            </div>
  
</div>
                </div>
     
        
        
        <?php
                //end of while loop...
            }
                        // end of else loop....
                    }
        ?>

    </div>
   

    <?php include("footer.php"); ?>
        <style>
            input[type=text],
            input[type=password] {
                width: 100%;
                height: 50px;
                padding: 12px 20px;
                margin: 8px 0;
                box-sizing: border-box;
                background-color: inherit;
            }
        </style>