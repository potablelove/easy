<?php
        session_start();

         $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
            
        $username = $_GET['username'];
        $password = $_GET['password'];
        if($username == "" || $password == ""){
            echo "one of the field is empty";
        }
        elseif($username > 4 || $username > 10 ){
            echo "Incorrect username";
        }
        elseif($password > 4){
            echo "wrong Password";
        }

        else{

 $sel = "SELECT * FROM ref where username = '$username' AND password = '$password'";
        $query = mysqli_query($conn,$sel) or die (mysqli_error($conn));
            $num = mysqli_num_rows($query);
            if($num < 1 ){
                echo "user does not Exist .....";
            }
            else{
                while($row = mysqli_fetch_assoc($query)){
                                $number = $row['number'];
                                  
                    $_SESSION['number'] = $row['number'];
                    $_SESSION['userid'] = $row['refid'];
                    
                    
                    ?>
        <a href="profile.php?number=<?php echo $number; ?>" class="btn btn-lg btn-success" >Continue</a>

<?php
                    
                }
            }
            
        }

?>