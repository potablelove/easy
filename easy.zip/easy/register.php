<?php
    $a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz";
            $sa =str_shuffle($a);
    $number = substr($sa,0,6);
   $conn =   mysqli_connect('localhost','root','','ref') or die('could not connect');
			$username = $_POST['username'];
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$password = $_POST['password'];
			$cpassword = $_POST['cpassword'];
		   @$gender = $_POST['gender'];
			$money = $_POST['money'];
			$dates = date('y/m/d @ h:i:sa');
            if($username=='' || $firstname =='' || $lastname =='' || $password=='' || $cpassword =='' || $gender =='' || $money==''){
                echo 'One of the field is empty';
            }
			elseif($password !== $cpassword){
				echo "Password did not match";
			}
			     else{
            
				$tmp = $_FILES['image']['tmp_name'];
				$name = $_FILES['image']['name'];
				$type = $_FILES['image']['type'];
				$size = $_FILES['image']['size'];
				$check = array('image/jpg','image/jpeg','image/png','image/gif');
				$path = 'picture/'.$name;
					if($size > 50000){
						echo "image too large";
					}
					else{
					if(!in_array($type,$check) || $name == ""){
						echo 'picture not supported';
					}
					else{
                      if(  file_exists($name)){
                          echo "file exists please choose another one";
                      }
					else {
				$ins = "INSERT INTO ref(username,firstname,lastname,password,gender,dates,picture,number,money) values ('$username','$firstname','$lastname','$password','$gender','$dates','$path','$number','$money')";
                        $query = mysqli_query($conn,$ins) or die(mysqli_error($conn));
                        if($query){
                            move_uploaded_file($tmp,'picture/'.$name);
                            echo "successful";
                        }
			 		}

                 }
                    }
                 }

?>